clear, clc;

%massa_sat = 0.311;
inercia_sat = 2.29204e-4;
vel_rads_sat = 0;


%massa_rd = 0.033;
inercia_rd = 3.17057e-5;
vel_rads_rd = 0;

L =  7.7e-3;        % ok
R = 11.3;           % ok
kv = 8.219178e-3;   % ok
JM = 9.5e-6;        % audacity
JL = inercia_rd;
J = JM + JL;

Va = 12;            % ok
Ts = 1/20;
%%

Ts = 1/20; % amostragem
Gz = c2d(cubeModel, Ts, 'zoh')
rltool(Gz)

%%

[num, den] = ss2tf(cubeModel.A, cubeModel.B, cubeModel.C, cubeModel.D);
tfCubeRads = tf(num, den)

integrator = tf([1], [1 0])
tfCubeRad = tfCubeRads * integrator

%%

Ts = 1/15; % amostragem
Gz = c2d(tfCubeRad, Ts, 'zoh')
rltool(Gz)
