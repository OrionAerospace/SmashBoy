#include "rpi_gpio.h"

#define PAGE_SIZE (4*1024)
#define BLOCK_SIZE (4*1024)

// GPIO setup macros. Always use INP_GPIO(x) before using OUT_GPIO(x) or SET_GPIO_ALT(x,y)
#define INP_GPIO(g) *(gpio+((g)/10)) &= ~(7<<(((g)%10)*3))
#define OUT_GPIO(g) *(gpio+((g)/10)) |=  (1<<(((g)%10)*3))
#define SET_GPIO_ALT(g,a) *(gpio+(((g)/10))) |= (((a)<=3?(a)+4:(a)==4?3:2)<<(((g)%10)*3))

#define GPIO_SET *(gpio+7)  // sets   bits which are 1 ignores bits which are 0
#define GPIO_CLR *(gpio+10) // clears bits which are 1 ignores bits which are 0

#define GET_GPIO(g) (*(gpio+13)&(1<<g)) // 0 if LOW, (1<<g) if HIGH

#define GPIO_PULL *(gpio+37) // Pull up/pull down
#define GPIO_PULLCLK0 *(gpio+38) // Pull up/pull down clock


// I/O access
volatile unsigned *gpio;

// Setup verification
static int setup_io_check = 0;

// Pinos disponiveis
int io_verify[] = { -1, -1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 
                    12, 13, 14, 15, 16, 17, 18, 19, 20, 21,
                    22, 23, 24, 25, 26 };

// Variavel que identificará se o pino já foi selecionado                       
int io_memory[] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                    0, 0, 0 };


void printButton(int8_t g)
{
  if (GET_GPIO(g)) // !=0 <-> bit is 1 <- port is HIGH=3.3V
    printf("Button pressed!\n");
  else // port is LOW=0V
    printf("Button released!\n");
}

int8_t gpio_set(int8_t g, int8_t state)
{
   if(io_memory[g] == 100)   // verifica se o gpio escolhido foi habilitado
   {  
      if(state == HIGH)
         GPIO_SET = 1<<g;
      else if(state == LOW)
         GPIO_CLR = 1<<g;
         
      return 1;
   } 
   else 
   {
      return -1;
   }
}

int8_t gpio_get(int8_t g)
{
   if(io_memory[g] == 50 || io_memory[g] == 100)    // verifica se o gpio escolhido foi habilitado
   {      
      if (GET_GPIO(g))       // !=0 <-> bit is 1 <- port is HIGH=3.3V
         return 1;
      else                   // port is LOW=0V
         return 0;
   }
   else {
      return -1;
   }
}


int8_t select_io(int8_t g, int8_t mode)
{
   int check = 0;
   
   // Verifica se a função setup foi chamada anteriormente
   if(setup_io_check == 0)                                              
   {
      #ifdef VERBOSE
      printf("seutp_io() needed\n");
      #endif
      return -1;
   }
   
   // Verifica se a IO inserida é valida
   for(int i = 0; i < 28; i++)
   {
      if(g == io_verify[i])      // Se for válida
      {
         check = 1;              // Set flag
         
         if(mode == OUTPUT)         // Set memory flag
            io_memory[i] = 100;     
            
         else if(mode == INPUT)     // Set memory flag
            io_memory[i] = 50;
      }
   }
   
   // Caso o número não esteja disponivel na saída de pinos
   if(check != 1)                
   {
      #ifdef VERBOSE
      printf("Erro: GPIO%d não disponivel na saida de pinos\n", g);
      #endif
      return 0; 
   }
  
   // Define o modo
   if(mode == OUTPUT)         
   {
      INP_GPIO(g);            // must use INP_GPIO before we can use OUT_GPIO
      OUT_GPIO(g);
   } else if(mode == INPUT) {
      INP_GPIO(g);
   }
  
   #ifdef VERBOSE
   if(mode == INPUT)  printf("Setup ok. GPIO%d, INPUT\n", g);
   else if(mode == OUTPUT)  printf("Setup ok. GPIO%d, OUTPUT\n", g);
   #endif

   return 1;
   
} // main

//
// Set up gpi pointer for direct register access
// Set up a memory regions to access GPIO
//
int8_t setup_io()
{
   int  mem_fd;
   void *gpio_map;   
   
   /* open /dev/mem */
   if ((mem_fd = open("/dev/mem", O_RDWR|O_SYNC) ) < 0) {
      #ifdef VERBOSE
      printf("can't open /dev/mem \n");
      printf("try sudo\n");
      #endif
      return -1;
   }
   
   /* mmap GPIO */
   gpio_map = mmap(
                     NULL,                   // Any adddress in our space will do
                     BLOCK_SIZE,             // Map length
                     PROT_READ|PROT_WRITE,   // Enable reading & writting to mapped memory
                     MAP_SHARED,             // Shared with other processes
                     mem_fd,                 // File to map
                     GPIO_BASE );            // Offset to GPIO peripheral

   close(mem_fd);             // No need to keep mem_fd open after mmap

   if (gpio_map == MAP_FAILED) {
      #ifdef VERBOSE
      printf("mmap error %d\n", (int)gpio_map); // errno also set!
      #endif
      return 0;
   }

   // Always use volatile pointer!
   gpio = (volatile unsigned *)gpio_map;

   setup_io_check = 1;        // Set flag
   
   return 1;
   
} // setup_io
