#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "inc/rpi_spi.h"
#include "inc/checksum.h"

#include <termios.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>

#define BAUDRATE	B115200
#define MODEMDEVICE	"/dev/ttyS0"

#define DEBUG_1
#define DEBUG_2
//#define DEBUG_3

void *spi_target = NULL;

int main(int argc, char **argv)
{
	FILE *pFile;														// Ponteiro pro arquivo
	long lSize;															// Tamanho total do arquivo
	uint8_t *buffer;													// Ponteiro pro buffer que conterá o arquivo
	size_t result;														// Variável auxiliar utilizada para verificar se o arquivo foi copiado pro buffer com sucesso

	// ------------------------ CONFIG UART ----------------------------
	
	int fd;
	struct termios uart;
	char uart_buffer[2];
	
	/*  Open modem device for reading and writing and not as controlling tty
        because we don't want to get killed if linenoise sends CTRL-C.    */    
	fd = open(MODEMDEVICE, O_RDWR | O_NOCTTY);
	if(fd < 0) { printf("Error: Open Serial\n"); exit(-1); }
	
	/* clear struct for new port settings */
	bzero(&uart, sizeof(uart));
	
	/*  BAUDRATE: Set bps rate. You could also use cfsetispeed and cfsetospeed.     
        CRTSCTS : output hardware flow control (only used if the cable has          
                     all necessary lines. See sect. 7 of Serial-HOWTO)              
        CS8     : 8n1 (8bit,no parity,1 stopbit)                                    
        CLOCAL  : local connection, no modem contol                                 
        CREAD   : enable receiving characters*/
	uart.c_cflag = BAUDRATE | CS8 | CLOCAL | CREAD;
	
	/* IGNPAR  : ignore bytes with parity errors */
	uart.c_iflag = IGNPAR;
	
	/* Raw output */
	uart.c_oflag = 0;
	
	/* set input mode (non-canonical, no echo,...) */ 
	uart.c_lflag = 0;
	
	uart.c_cc[VTIME]    = 0;   /* inter-character timer unused */
	uart.c_cc[VMIN]     = 1;   /* blocking read until 5 chars received */
	
	tcflush(fd, TCIFLUSH);
	tcsetattr(fd, TCSANOW, &uart);
	
	//read(fd, uart_buffer, 2);
	//uart_buffer[1] = 0;
	//printf("recebido: %s\n", uart_buffer); 

	// ----------------------- END CONFIG UART -------------------------
	
	// ------------------------ OPEN THE PICTURE -----------------------
	
	printf("ready to take the picture..\n");
	do
	{
		uart_buffer[0] = 0;
		read(fd, uart_buffer, 2);
	} 
	while (uart_buffer[0] != 'S');										// aguarda pelo comando
	
	// aqui deve ter a função que irá tirar a foto
	
	// ---------------------- END OPEN THE PICTURE ---------------------

	pFile = fopen("images/pluto128.jpg","rb");							// Abre a imagem como arquivo binário
	if(pFile == NULL) { printf("File error \n"); exit (1); }			// Verifica se deu certo

	// Obtem o tamanho do arquivo
	fseek(pFile, 0, SEEK_END);											// For streams open in binary mode, the new position is defined by adding offset to a reference position specified by origin.
	lSize = ftell(pFile);												// Com a posição do ponteiro definida no final do arquivo, está função obtem seu tamanho
	rewind(pFile);														// Retorna o ponteiro pro inicio
	
	buffer = (uint8_t *) malloc(sizeof(uint8_t) * lSize);				// Aloca memória pro arquivo e retorna o ponteiro pra posição inicial dao arquivo na memória
	if(buffer == NULL) { printf("Memory error \n"); exit (2); }			// Verifica se deu certo
	
	result = fread(buffer, 1, lSize, pFile);							// Realiza a leitura do arquivo e coloca os bytes onde havia sido alocado a memória no passo anterior
	if(result != lSize) { printf("Reading error \n"); exit (3); }		// Verifica se a leitura foi bem sucedida
	
	fclose(pFile);														// Como o arquvio já foi copiado com sucesso para o buffer, encerra o arquivo e libera memória
	
	#ifdef DEBUG_1
	// Debug, isso aq mostra os binarios da imagem na integra
	printf("\n----------------------------------------------------------\n");
	printf("--------------------DEBUG-FULL-MESSAGE--------------------\n");
	for(int i = 0; i < lSize; i++)
	{
		if(i % 0x800 == 0 && i != 0) printf("--------");				// Divisão visual entre as mensagens
		printf("%.2X", *(buffer+i) );
	}	
	printf("\n\nSize: %ld bytes", lSize);
	printf("\n---------------------------END----------------------------");
	printf("\n----------------------------------------------------------\n\n");	
	#endif
	
	/*
	 * O ID é de trás pra frente, assim da pra saber quantos
	 *  pacotes ainda faltam
	 *
	 *	(hex)       id  + len 
	 * message: (ID0000 + 000 + payloads 2048 bytes) + crc32
	 * 
	 * o CRC é da mensagem toda, assim é possivel saber se qualquer parte
	 *   dela foi corrompida durante a transferência
	 */
	
	uint32_t pkt_crc;													// CRC 32 bits do pacote parcial que será enviada
	uint16_t pkt_id, pkt_msg_size;										// ID e tamanho do Payload
	uint8_t *pkt_buffer;												// ponteiro pro pacote
	
	/* Aloca memória pro buffer (em bytes) que transmitirá a mensagem (2048 bytes) + header (32 bits: 16 bits ID + 16 bits Size) + CRC (32 bits)
	 * Diferente do outro buffer, esse possui um tamanho fixo (que é um tamanho bom que o microcontrolador aceita) este buffer é responsável
	 *  por subdividir o buffer anterior. */
	pkt_buffer = (uint8_t *) malloc(sizeof(uint8_t) * (0x800 + 8) );
	if(pkt_buffer == NULL) { printf("Memory error \n"); exit (4); }		// Verifica se deu certo
	
	uint16_t frag_pkt_size = lSize/0x800;								// Quantidade de fragmentos nessessários para enviar o arquivo
	
	#ifdef DEBUG_2
	printf("\n----------------------------------------------------------\n");
	printf("-------------------DEBUG-PACKET-MESSAGE-------------------\n\n");
	#endif
	
	if(spi_open(&spi_target) < 0) {										// Aloca memória para o SPI
		printf("Error: SPI Open"); exit(-1); }						
	
	for(int i = 0; i <= frag_pkt_size; i++)								// Pacotes de 2048 bytes, subdivide o arquivo em pacotes caso o tamanho seja maior que isso
	{
		pkt_id = frag_pkt_size - i;										// O ID tbm é a quantidade de pacotes restantes
		
		if(pkt_id > 0)	pkt_msg_size = 0x800;							// Se não for o último, sempre terá o tamanho máximo
		else 			pkt_msg_size = lSize - (0x800*frag_pkt_size);	// Se for o último pacote, o tamanho será variavel
		
		#ifdef DEBUG_2
		printf("ID%.4X%.4X#", pkt_id, pkt_msg_size );					// Debug, mostra na tela o ID e o Tamanho
		#endif
		
		*(pkt_buffer + 0) = (pkt_id & 0xFF00) >> 8;						// Adiciona o ID ao pacote
		*(pkt_buffer + 1) = pkt_id & 0xFF;
		*(pkt_buffer + 2) = (pkt_msg_size & 0xFF00) >> 8;				// Adiciona o tamanho ao pacote
		*(pkt_buffer + 3) = pkt_msg_size & 0xFF;
		
		for(int j = 0; j < pkt_msg_size; j++)							// Loop de preenchimento do buffer de acordo com o tamanho do pacote
		{
			#ifdef DEBUG_2
			printf("%.2X", *(buffer + j + (i*0x800)) );					// Debug, mostra o que está sendo preenchido
			#endif
			*(pkt_buffer + 4 + j) = *(buffer + j + (i*0x800));			// Preenche o buffer de envio
		}
		
		pkt_crc = crc_32(pkt_buffer, pkt_msg_size + 4);					// Calcula o CRC32 do pacote
		*(pkt_buffer + pkt_msg_size + 4 + 0) = (pkt_crc & 0xFF000000) >> 24;	// Insere o CRC no buffer que será transmitido
		*(pkt_buffer + pkt_msg_size + 4 + 1) = (pkt_crc & 0xFF0000) >> 16;
		*(pkt_buffer + pkt_msg_size + 4 + 2) = (pkt_crc & 0xFF00) >> 8;
		*(pkt_buffer + pkt_msg_size + 4 + 3) =  pkt_crc & 0xFF;
		
		#ifdef DEBUG_2
		printf(" CRC:%X", pkt_crc);										// Debug, mostra o valor do CRC
		printf("\n\n");
		#endif
		
		
		#ifndef DEBUG_2
		#ifdef DEBUG_3
		for(int j = 0; j < (pkt_msg_size + 8); j++)
		{
			printf("%.2X", *(pkt_buffer + j) );							// Isso é o equivalente ao que deve sair pelo SPI	
		}
		printf("\n-----------------------------------\n");
		
		printf("aguardando comando..\n");
		#endif
		#endif
		
		
		spi_w(spi_target, pkt_buffer, 0x808);							// Envia a parcela do arquivo
		
		do
		{
			uart_buffer[0] = 0;
			read(fd, uart_buffer, 2);									// aguarda receber comando para enviar a proxima parte
			
			switch (uart_buffer[0])
			{
				case 'P':												// Comando que envia a mesma parcela novamente (caso de BAD CRC)
					spi_w(spi_target, pkt_buffer, 0x808);
					break;
					
				default:
					break;
			}
					
		} while (uart_buffer[0] != 'N');	
		
	}

	#ifdef DEBUG_2
	printf("Size: %ld bytes", lSize);
	#endif
	


	
	
	
	
	
	
	
	/*
	spi_open(&spi_target);
	if(lSize <= 0xFFF)
	{ spi_w(spi_target, buffer, lSize); }
	else
	{
		for(int i = 0; i <= lSize/0xFFF; i++)
		{
			if(i == lSize/0xFFF) {
				spi_w(spi_target, buffer + (0xFFF * i), lSize - (i*0xFFF) ); }
			
			else {
				spi_w(spi_target, buffer + (0xFFF * i), 0xFFF); }
		}
	}
	spi_close(spi_target);
	
	
	pFile = fopen("imageCopy.jpg","wb");
	if(pFile == NULL) { printf("File error \n"); exit (1); }
	fwrite(buffer, 1, lSize, pFile);
	fclose(pFile);
	*/
	
	
	spi_close(spi_target);												// libera memória alocada para o SPI
	close(fd);															// libera memória alocada para o UART
	free(buffer);														// libera memória alocada para o arquivo
	free(pkt_buffer);													// libera memória alocada para o arquivo parcial (2056 bytes)
	
	printf("\nfinish\n");
	
	return 0;
}

