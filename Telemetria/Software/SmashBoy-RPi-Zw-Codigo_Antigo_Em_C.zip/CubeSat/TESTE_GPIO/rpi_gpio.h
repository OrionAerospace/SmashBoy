#ifndef _GPIO_RASP_H
#define _GPIO_RASP_H 

/*
 *  How to access GPIO registers from C-code on the Raspberry-Pi
 *  Example program
 *  15-January-2012
 *  Dom and Gert
 *  Revised: 15-Feb-2013
 *  https://elinux.org/RPi_GPIO_Code_Samples#Direct_register_access
 *
 *  Adapted: Henrique
 *	19-May-2020
 * 
 *  Access from ARM Running Linux
 *  Note: For Raspberry Pi 2 and Pi 3, change BCM2708_PERI_BASE to 0x3F000000 for the code to work.
 *
 */

//#define BCM2708_PERI_BASE        0x20000000  							// original, para PI 1 e Zero
#define BCM2708_PERI_BASE        0x3F000000								// modificado conforme a nota a cima
#define GPIO_BASE                (BCM2708_PERI_BASE + 0x200000) /* GPIO controller */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>

#define INPUT	1
#define OUTPUT	0
#define	HIGH	1
#define	LOW		0

int8_t setup_io();

int8_t select_io(int8_t g, int8_t mode);

int8_t gpio_set(int8_t g, int8_t state);

int8_t gpio_get(int8_t g);


void printButton(int8_t g);

#endif
