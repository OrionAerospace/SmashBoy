/* -------------------------------------------------------------------------- */
/* --- DEPENDANCIES --------------------------------------------------------- */

#include <stdint.h>			/* C99 types */
#include <stdio.h>			/* printf fprintf */
#include <stdlib.h>			/* malloc free */
#include <unistd.h>			/* lseek, close */
#include <fcntl.h>			/* open */
#include <string.h>			/* memset */

#include <sys/ioctl.h>
#include <linux/spi/spidev.h>

#include "../inc/rpi_spi.h"

/* -------------------------------------------------------------------------- */
/* --- PRIVATE MACROS ------------------------------------------------------- */

#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))
#if DEBUG_SPI == 1
    #define DEBUG_MSG(str)                fprintf(stderr, str)
    #define DEBUG_PRINTF(fmt, args...)    fprintf(stderr,"%s:%d: "fmt, __FUNCTION__, __LINE__, args)
    #define CHECK_NULL(a)                if(a==NULL){fprintf(stderr,"%s:%d: ERROR: NULL POINTER AS ARGUMENT\n", __FUNCTION__, __LINE__);return LGW_SPI_ERROR;}
#else
    #define DEBUG_MSG(str)
    #define DEBUG_PRINTF(fmt, args...)
    #define CHECK_NULL(a)                if(a==NULL){return SPI_ERROR;}
#endif

/* -------------------------------------------------------------------------- */
/* --- PRIVATE CONSTANTS ---------------------------------------------------- */

#define READ_ACCESS     0x00
#define WRITE_ACCESS    0x80
#define SPI_SPEED       8000000
#define SPI_DEV_PATH    "/dev/spidev0.0"
//#define SPI_DEV_PATH    "/dev/spidev32766.0"

/* -------------------------------------------------------------------------- */
/* --- PUBLIC FUNCTIONS DEFINITION ------------------------------------------ */

/* SPI initialization and configuration */
int spi_open(void **spi_target_ptr) {
    int *spi_device = NULL;
    int dev;
    int a=0, b=0;
    int i;

    /* check input variables */
    CHECK_NULL(spi_target_ptr); /* cannot be null, must point on a void pointer (*spi_target_ptr can be null) */

    /* allocate memory for the device descriptor */
    spi_device = malloc(sizeof(int));
    if (spi_device == NULL) {
        DEBUG_MSG("ERROR: MALLOC FAIL\n");
        return SPI_ERROR;
    }

    /* open SPI device */
    dev = open(SPI_DEV_PATH, O_RDWR);
    if (dev < 0) {
        DEBUG_PRINTF("ERROR: failed to open SPI device %s\n", SPI_DEV_PATH);
        return SPI_ERROR;
    }

    /* setting SPI mode to 'mode 0' */
    i = SPI_MODE_0;												// definido em spidev.h
    a = ioctl(dev, SPI_IOC_WR_MODE, &i);
    b = ioctl(dev, SPI_IOC_RD_MODE, &i);
    if ((a < 0) || (b < 0)) {
        DEBUG_MSG("ERROR: SPI PORT FAIL TO SET IN MODE 0\n");
        close(dev);
        free(spi_device);
        return SPI_ERROR;
    }

    /* setting SPI max clk (in Hz) */
    i = SPI_SPEED;
    a = ioctl(dev, SPI_IOC_WR_MAX_SPEED_HZ, &i);
    b = ioctl(dev, SPI_IOC_RD_MAX_SPEED_HZ, &i);
    if ((a < 0) || (b < 0)) {
        DEBUG_MSG("ERROR: SPI PORT FAIL TO SET MAX SPEED\n");
        close(dev);
        free(spi_device);
        return SPI_ERROR;
    }

    /* setting SPI to MSB first */
    i = 0;
    a = ioctl(dev, SPI_IOC_WR_LSB_FIRST, &i);
    b = ioctl(dev, SPI_IOC_RD_LSB_FIRST, &i);
    if ((a < 0) || (b < 0)) {
        DEBUG_MSG("ERROR: SPI PORT FAIL TO SET MSB FIRST\n");
        close(dev);
        free(spi_device);
        return SPI_ERROR;
    }

    /* setting SPI to 8 bits per word */
    i = 0;
    a = ioctl(dev, SPI_IOC_WR_BITS_PER_WORD, &i);
    b = ioctl(dev, SPI_IOC_RD_BITS_PER_WORD, &i);
    if ((a < 0) || (b < 0)) {
        DEBUG_MSG("ERROR: SPI PORT FAIL TO SET 8 BITS-PER-WORD\n");
        close(dev);
        return SPI_ERROR;
    }

    *spi_device = dev;
    *spi_target_ptr = (void *)spi_device;
    DEBUG_MSG("Note: SPI port opened and configured ok\n");
    return SPI_SUCCESS;
}

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

/* SPI release */
int spi_close(void *spi_target) {
    int spi_device;
    int a;

    /* check input variables */
    CHECK_NULL(spi_target);

    /* close file & deallocate file descriptor */
    spi_device = *(int *)spi_target; /* must check that spi_target is not null beforehand */
    a = close(spi_device);
    free(spi_target);

    /* determine return code */
    if (a < 0) {
        DEBUG_MSG("ERROR: SPI PORT FAILED TO CLOSE\n");
        return SPI_ERROR;
    } else {
        DEBUG_MSG("Note: SPI port closed\n");
        return SPI_SUCCESS;
    }
}

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

/* Simple write */
int spi_w(void *spi_target, uint8_t *data, uint16_t lenght) {
    int spi_device;
    struct spi_ioc_transfer k;
    int a;

    /* check input variables */
    CHECK_NULL(spi_target);

    spi_device = *(int *)spi_target; /*   must check that spi_target is not null beforehand 
										* converte 'spi_target' pra um ponteiro pra inteiro
										*  e 'spi_device' recebe o valor que ele aponta			 */

    /* I/O transaction */
    memset(&k, 0, sizeof(k)); 						/* clear k */
    k.tx_buf = (unsigned long) data;
    k.len = lenght;
    k.speed_hz = SPI_SPEED;
    k.cs_change = 0;
    k.bits_per_word = 8;
    a = ioctl(spi_device, SPI_IOC_MESSAGE(1), &k);

    /* determine return code */
    if (a != (int)k.len) {
        DEBUG_MSG("ERROR: SPI WRITE FAILURE\n");
        return SPI_ERROR;
    } else {
        DEBUG_MSG("Note: SPI write success\n");
        return SPI_SUCCESS;
    }
}

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

///* Simple read */
//int lgw_spi_r(void *spi_target, uint8_t spi_mux_mode, uint8_t spi_mux_target, uint8_t address, uint8_t *data) {
    //int spi_device;
    //uint8_t out_buf[3];
    //uint8_t command_size;
    //uint8_t in_buf[ARRAY_SIZE(out_buf)];
    //struct spi_ioc_transfer k;
    //int a;

    ///* check input variables */
    //CHECK_NULL(spi_target);
    //if ((address & 0x80) != 0) {
        //DEBUG_MSG("WARNING: SPI address > 127\n");
    //}
    //CHECK_NULL(data);

    //spi_device = *(int *)spi_target; /* must check that spi_target is not null beforehand */

    ///* prepare frame to be sent */
    //if (spi_mux_mode == LGW_SPI_MUX_MODE1) {
        //out_buf[0] = spi_mux_target;
        //out_buf[1] = READ_ACCESS | (address & 0x7F);
        //out_buf[2] = 0x00;
        //command_size = 3;
    //} else {
        //out_buf[0] = READ_ACCESS | (address & 0x7F);
        //out_buf[1] = 0x00;
        //command_size = 2;
    //}

    ///* I/O transaction */
    //memset(&k, 0, sizeof(k)); /* clear k */
    //k.tx_buf = (unsigned long) out_buf;
    //k.rx_buf = (unsigned long) in_buf;
    //k.len = command_size;
    //k.cs_change = 0;
    //a = ioctl(spi_device, SPI_IOC_MESSAGE(1), &k);

    ///* determine return code */
    //if (a != (int)k.len) {
        //DEBUG_MSG("ERROR: SPI READ FAILURE\n");
        //return LGW_SPI_ERROR;
    //} else {
        //DEBUG_MSG("Note: SPI read success\n");
        //*data = in_buf[command_size - 1];
        //return LGW_SPI_SUCCESS;
    //}
//}

///* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

