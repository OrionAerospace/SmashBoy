# cubSat
Codigo do cubSat - Raspberry
