16/09/2020

Criada a pasta SmashBoy, aqui estará todo o novo código.

Em maio eu havia escrito um código em C, mas como a câmera funciona com um código em Python, então acho que não haverá uma mudança
 significativa de desempenho se todo o algoritmo do raspberry for em Python. Além disso, em Python fica mais simples para ser lido
 pelas próximas pessoas que estarão fazendo parte da equipe.



